import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

import { requireUser } from "@/lib/auth";
import { jsonError, safeError } from "@/lib/http";

import {
  documentSchema
} from "@/server/documentation/validators/document.schema";

import {
  getDocuments,
  createDocument
} from "@/server/documentation/services/document.service";



export async function GET(
 request:NextRequest
){

try{

const user =
 await requireUser(request);


if(!user){

 return jsonError(
  "Unauthorized.",
  401
 );

}


const documents =
 await getDocuments({

 userId:user.id,

 search:
 request.nextUrl.searchParams
 .get("search")
 ?.trim(),

 language:
 request.nextUrl.searchParams
 .get("language")
 ?.trim(),

 category:
 request.nextUrl.searchParams
 .get("category")
 ?.trim(),

 scope:
 request.nextUrl.searchParams
 .get("scope")
 ?.trim()
 ||
 "mine"

});


return NextResponse.json({

 documents

});


}catch(error){

console.error(error);

return safeError(error);

}

}





export async function POST(
 request:NextRequest
){

try{

const user =
 await requireUser(request);


if(!user){

 return jsonError(
 "Unauthorized.",
 401
 );

}



const parsed =
 documentSchema.safeParse(
  await request.json()
 );


if(!parsed.success){

return jsonError(
 "Invalid document data.",
 422,
 parsed.error.flatten()
);

}



const document =
 await createDocument(
  user.id,
  parsed.data
 );


return NextResponse.json(
 {
  document
 },
 {
  status:201
 }
);



}catch(error){

console.error(error);

return safeError(error);

}

}