import { NextResponse } from "next/server";

import { getServerSession } from "@/lib/auth";
import {
  getOwnProfile,
  updateOwnProfile,
} from "@/server/profile/profile.service";

/*
|--------------------------------------------------------------------------
| GET /api/profile
|--------------------------------------------------------------------------
*/

export async function GET() {
  const user = await getServerSession();

  if (!user) {
    return NextResponse.json(
      {
        error: "Unauthorized.",
      },
      {
        status: 401,
      },
    );
  }

  try {
    const profile = await getOwnProfile(
      user.id,
    );

    return NextResponse.json({
      profile,
    });
  } catch (error) {
    console.error(
      "GET PROFILE ERROR:",
      error,
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Unable to load profile.",
      },
      {
        status: 400,
      },
    );
  }
}

/*
|--------------------------------------------------------------------------
| PUT /api/profile
|--------------------------------------------------------------------------
*/

export async function PUT(
  request: Request,
) {
  const user = await getServerSession();

  if (!user) {
    return NextResponse.json(
      {
        error: "Unauthorized.",
      },
      {
        status: 401,
      },
    );
  }

  try {
    const body = await request.json();

    const name =
      typeof body?.name === "string"
        ? body.name
        : "";

    const bio =
      typeof body?.bio === "string"
        ? body.bio
        : null;

    const profile =
      await updateOwnProfile({
        userId: user.id,
        name,
        bio,
      });

    return NextResponse.json({
      success: true,
      profile,
    });
  } catch (error) {
    console.error(
      "UPDATE PROFILE ERROR:",
      error,
    );

    return NextResponse.json(
      {
        error:
          error instanceof Error
            ? error.message
            : "Unable to update profile.",
      },
      {
        status: 400,
      },
    );
  }
}